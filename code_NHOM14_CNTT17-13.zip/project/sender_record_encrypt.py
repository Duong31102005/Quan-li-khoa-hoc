import sounddevice as sd
from scipy.io.wavfile import write
import os
import base64
import json
from datetime import datetime
from Crypto.Cipher import DES3
from Crypto.Random import get_random_bytes
import hashlib
import rsa

# ========================
# BƯỚC 1: GHI ÂM
# ========================
fs = 44100  # Tần số mẫu
duration = 5  # Số giây ghi âm

print("🎤 Bắt đầu ghi âm trong 5 giây...")
recording = sd.rec(int(duration * fs), samplerate=fs, channels=2)
sd.wait()
print("✅ Đã ghi âm xong!")

filename = "recording.wav"
write(filename, fs, recording)
print(f"💾 Đã lưu file: {filename}")

# ========================
# BƯỚC 2: LOAD KHÓA
# ========================
with open("sender_private.pem", "rb") as f:
    sender_priv = rsa.PrivateKey.load_pkcs1(f.read())

with open("receiver_public.pem", "rb") as f:
    receiver_pub = rsa.PublicKey.load_pkcs1(f.read())

with open("step2_sent_data.json", "r") as f:
    data = json.load(f)

session_key = rsa.decrypt(base64.b64decode(data["encrypted_session_key"]),
                          rsa.PrivateKey.load_pkcs1(open("receiver_private.pem", "rb").read()))

# ========================
# BƯỚC 3: ĐỌC FILE GHI ÂM
# ========================
with open(filename, "rb") as f:
    audio_data = f.read()

chunk_size = len(audio_data) // 3
chunks = [audio_data[i*chunk_size : (i+1)*chunk_size] for i in range(2)]
chunks.append(audio_data[2*chunk_size:])

encrypted_chunks = []

for i, chunk in enumerate(chunks):
    iv = get_random_bytes(8)
    cipher = DES3.new(session_key, DES3.MODE_CBC, iv)

    pad_len = 8 - len(chunk) % 8
    padded_chunk = chunk + bytes([pad_len]) * pad_len
    ciphertext = cipher.encrypt(padded_chunk)

    hash_val = hashlib.sha512(iv + ciphertext).digest()
    signature = rsa.sign(hash_val, sender_priv, 'SHA-512')

    encrypted_chunks.append({
        "part": i+1,
        "iv": base64.b64encode(iv).decode(),
        "ciphertext": base64.b64encode(ciphertext).decode(),
        "hash": base64.b64encode(hash_val).decode(),
        "signature": base64.b64encode(signature).decode()
    })

# ========================
# BƯỚC 4: GHI FILE ĐÃ MÃ HÓA
# ========================
with open("encrypted_parts.json", "w") as f:
    json.dump(encrypted_chunks, f, indent=4)

print("✅ Đã mã hóa và lưu vào encrypted_parts.json.")
