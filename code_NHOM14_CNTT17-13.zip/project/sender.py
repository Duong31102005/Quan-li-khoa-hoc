# sender.py
import socket, os, json, base64, hashlib, rsa # type: ignore
from datetime import datetime
from Crypto.Cipher import DES3
from Crypto.Random import get_random_bytes

HOST = 'localhost'
PORT = 12345
FILE_PATH = 'recording.mp3'

# Load khóa
with open("receiver_public.pem", "rb") as f:
    receiver_pub = rsa.PublicKey.load_pkcs1(f.read())
with open("sender_private.pem", "rb") as f:
    sender_priv = rsa.PrivateKey.load_pkcs1(f.read())

def split_file(path, parts=3):
    with open(path, "rb") as f:
        data = f.read()
    size = len(data) // parts
    return [data[i*size:(i+1)*size] if i < parts-1 else data[i*size:] for i in range(parts)]

def encrypt_chunk(chunk, key, priv_key):
    iv = get_random_bytes(8)
    cipher = DES3.new(key, DES3.MODE_CBC, iv)

    pad = 8 - len(chunk) % 8
    chunk += bytes([pad])*pad
    ct = cipher.encrypt(chunk)
    
    hash_val = hashlib.sha512(iv + ct).hexdigest()
    sig = rsa.sign(hash_val.encode(), priv_key, 'SHA-512')

    return {
        "iv": base64.b64encode(iv).decode(),
        "cipher": base64.b64encode(ct).decode(),
        "hash": hash_val,
        "sig": base64.b64encode(sig).decode()
    }

def main():
    s = socket.socket()
    s.connect((HOST, PORT))

    s.sendall(b"Hello!")
    if s.recv(1024).decode() != "Ready!":
        print("Receiver not ready!")
        return

    session_key = DES3.adjust_key_parity(get_random_bytes(24))
    enc_key = rsa.encrypt(session_key, receiver_pub)
    s.sendall(len(enc_key).to_bytes(4, 'big') + enc_key)

    metadata = {
        "filename": os.path.basename(FILE_PATH),
        "time": str(datetime.now()),
        "size": os.path.getsize(FILE_PATH)
    }
    meta_bytes = json.dumps(metadata).encode()
    sig = rsa.sign(meta_bytes, sender_priv, 'SHA-512')
    s.sendall(len(meta_bytes).to_bytes(4, 'big') + meta_bytes)
    s.sendall(len(sig).to_bytes(4, 'big') + sig)

    chunks = split_file(FILE_PATH)
    for i, part in enumerate(chunks):
        pkg = encrypt_chunk(part, session_key, sender_priv)
        raw = json.dumps(pkg).encode()
        s.sendall(len(raw).to_bytes(4, 'big') + raw)
        print(f"Sent part {i+1}/3")

    response = s.recv(1024).decode()
    print("Receiver:", response)
    s.close()

if __name__ == "__main__":
    main()
