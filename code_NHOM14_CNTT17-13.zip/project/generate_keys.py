# generate_keys.py
import rsa

# Sender
sender_pub, sender_priv = rsa.newkeys(2048)
with open("sender_public.pem", "wb") as f:
    f.write(sender_pub.save_pkcs1())
with open("sender_private.pem", "wb") as f:
    f.write(sender_priv.save_pkcs1())

# Receiver
receiver_pub, receiver_priv = rsa.newkeys(2048)
with open("receiver_public.pem", "wb") as f:
    f.write(receiver_pub.save_pkcs1())
with open("receiver_private.pem", "wb") as f:
    f.write(receiver_priv.save_pkcs1())

print("Khóa RSA đã được tạo.")
