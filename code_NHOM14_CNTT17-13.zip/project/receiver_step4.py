import rsa
import json
import base64
import hashlib
from Crypto.Cipher import DES3

# ----- Load khóa công khai người gửi và khóa riêng người nhận -----
with open("sender_public.pem", "rb") as f:
    sender_pub = rsa.PublicKey.load_pkcs1(f.read())

with open("receiver_private.pem", "rb") as f:
    receiver_priv = rsa.PrivateKey.load_pkcs1(f.read())

# ----- Load metadata và session key -----
with open("step2_sent_data.json", "r") as f:
    data = json.load(f)

# 1. Giải mã session key
encrypted_session_key = base64.b64decode(data["encrypted_session_key"])
session_key = rsa.decrypt(encrypted_session_key, receiver_priv)

# 2. Xác minh metadata
metadata_bytes = base64.b64decode(data["metadata"])
signature = base64.b64decode(data["signature"])

hash_md = rsa.compute_hash(metadata_bytes, 'SHA-512')

try:
    rsa.verify(metadata_bytes, signature, sender_pub)
    print("✅ Chữ ký metadata hợp lệ.")
except rsa.VerificationError:
    print("❌ Chữ ký metadata KHÔNG hợp lệ.")
    exit()
# ----- Load 3 phần mã hóa -----
with open("encrypted_parts.json", "r") as f:
    parts = json.load(f)

output_data = b""

for part in parts:
    print(f"\n📦 Đang xử lý phần {part['part']}")

    iv = base64.b64decode(part["iv"])
    ciphertext = base64.b64decode(part["ciphertext"])
    received_hash = base64.b64decode(part["hash"])
    signature = base64.b64decode(part["signature"])

    # Tính lại hash
    hash_check = hashlib.sha512(iv + ciphertext).digest()

    if hash_check != received_hash:
        print("❌ Hash không khớp. Dữ liệu bị thay đổi!")
        continue

    # Xác minh chữ ký
    try:
        rsa.verify(received_hash, signature, sender_pub)
        print("✅ Chữ ký phần này hợp lệ.")
    except rsa.VerificationError:
        print("❌ Chữ ký phần này KHÔNG hợp lệ.")
        continue

    # Giải mã
    cipher = DES3.new(session_key, DES3.MODE_CBC, iv)
    padded_data = cipher.decrypt(ciphertext)

    # Bỏ padding
    pad_len = padded_data[-1]
    decrypted_data = padded_data[:-pad_len]

    output_data += decrypted_data

# ----- Ghi lại file mp3 kết quả -----
with open("received_output.mp3", "wb") as f:
    f.write(output_data)

print("\n🎧 Đã ghép xong file: received_output.mp3")
