import rsa
import json
import base64
import os
from Crypto.Cipher import DES3
from Crypto.Random import get_random_bytes
import hashlib

# ----- Load khóa -----
with open("sender_private.pem", "rb") as f:
    sender_priv = rsa.PrivateKey.load_pkcs1(f.read())

# ----- Load session key từ bước 2 -----
with open("step2_sent_data.json", "r") as f:
    data = json.load(f)
session_key = rsa.decrypt(base64.b64decode(data["encrypted_session_key"]), rsa.PrivateKey.load_pkcs1(open("receiver_private.pem", "rb").read()))

# ----- Load file âm thanh -----
with open("recording.mp3", "rb") as f:
    audio_data = f.read()

# ----- Chia thành 3 phần -----
chunk_size = len(audio_data) // 3
chunks = [audio_data[i*chunk_size : (i+1)*chunk_size] for i in range(2)]
chunks.append(audio_data[2*chunk_size:])  # phần còn lại

encrypted_chunks = []

for i, chunk in enumerate(chunks):
    # Tạo IV mới cho mỗi phần
    iv = get_random_bytes(8)
    cipher = DES3.new(session_key, DES3.MODE_CBC, iv)

    # Padding để đủ block 8 byte
    pad_len = 8 - len(chunk) % 8
    padded_chunk = chunk + bytes([pad_len]) * pad_len

    ciphertext = cipher.encrypt(padded_chunk)

    # Hash SHA-512
    hash_val = hashlib.sha512(iv + ciphertext).digest()

    # Ký số hash
    signature = rsa.sign(hash_val, sender_priv, 'SHA-512')

    # Ghi từng phần ra
    encrypted_chunks.append({
        "part": i+1,
        "iv": base64.b64encode(iv).decode(),
        "ciphertext": base64.b64encode(ciphertext).decode(),
        "hash": base64.b64encode(hash_val).decode(),
        "signature": base64.b64encode(signature).decode()
    })

# ----- Ghi ra file mô phỏng dữ liệu gửi đi -----
with open("encrypted_parts.json", "w") as f:
    json.dump(encrypted_chunks, f, indent=4)

print("✅ Đã chia file, mã hóa 3 phần, ký số và lưu vào encrypted_parts.json.")
