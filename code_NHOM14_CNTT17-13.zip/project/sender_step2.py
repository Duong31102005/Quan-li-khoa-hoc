import rsa
import json
import base64
import os
from datetime import datetime

# ----- Load khóa -----
with open("sender_private.pem", "rb") as f:
    sender_priv = rsa.PrivateKey.load_pkcs1(f.read())

with open("receiver_public.pem", "rb") as f:
    receiver_pub = rsa.PublicKey.load_pkcs1(f.read())

# ----- Tạo Session Key cho Triple DES (24 bytes) -----
session_key = os.urandom(24)  # 192-bit

# ----- Tạo metadata -----
metadata = {
    "filename": "recording.mp3",
    "timestamp": datetime.utcnow().isoformat(),
    "duration": "30s"  # bạn có thể lấy thật nếu muốn
}

metadata_bytes = json.dumps(metadata).encode()

# ----- Ký số metadata -----
hash_md = rsa.compute_hash(metadata_bytes, 'SHA-512')
signature = rsa.sign_hash(hash_md, sender_priv, 'SHA-512')

# ----- Mã hóa Session Key bằng khóa công khai người nhận -----
encrypted_session_key = rsa.encrypt(session_key, receiver_pub)

# ----- Ghi tất cả ra file (mô phỏng truyền đi) -----
sent_data = {
    "metadata": base64.b64encode(metadata_bytes).decode(),
    "signature": base64.b64encode(signature).decode(),
    "encrypted_session_key": base64.b64encode(encrypted_session_key).decode()
}

with open("step2_sent_data.json", "w") as f:
    json.dump(sent_data, f, indent=4)

print("✅ Đã tạo metadata, ký số và mã hóa Session Key.")
