# receiver.py
import socket, os, json, base64, hashlib, rsa
from Crypto.Cipher import DES3

HOST = 'localhost'
PORT = 12345

with open("receiver_private.pem", "rb") as f:
    receiver_priv = rsa.PrivateKey.load_pkcs1(f.read())
with open("sender_public.pem", "rb") as f:
    sender_pub = rsa.PublicKey.load_pkcs1(f.read())

def decrypt_chunk(data, key):
    iv = base64.b64decode(data["iv"])
    ct = base64.b64decode(data["cipher"])
    cipher = DES3.new(key, DES3.MODE_CBC, iv)
    pt = cipher.decrypt(ct)
    pad = pt[-1]
    return pt[:-pad]

def main():
    s = socket.socket()
    s.bind((HOST, PORT))
    s.listen(1)
    conn, addr = s.accept()

    if conn.recv(1024).decode() != "Hello!":
        return
    conn.sendall(b"Ready!")

    key_len = int.from_bytes(conn.recv(4), 'big')
    session_key = rsa.decrypt(conn.recv(key_len), receiver_priv)

    meta_len = int.from_bytes(conn.recv(4), 'big')
    metadata = json.loads(conn.recv(meta_len).decode())
    sig_len = int.from_bytes(conn.recv(4), 'big')
    signature = conn.recv(sig_len)
    rsa.verify(json.dumps(metadata).encode(), signature, sender_pub)
    print("Metadata hợp lệ!")

    chunks = []
    for i in range(3):
        plen = int.from_bytes(conn.recv(4), 'big')
        packet = json.loads(conn.recv(plen).decode())

        hash_val = hashlib.sha512(base64.b64decode(packet["iv"]) + base64.b64decode(packet["cipher"])).hexdigest()
        try:
            rsa.verify(hash_val.encode(), base64.b64decode(packet["sig"]), sender_pub)
            chunks.append(decrypt_chunk(packet, session_key))
            print(f"Đã nhận phần {i+1}/3")
        except:
            conn.sendall(b"NACK")
            conn.close()
            return

    with open("received_recording.mp3", "wb") as f:
        for part in chunks:
            f.write(part)
    print("Gộp file hoàn tất!")
    conn.sendall(b"ACK")
    conn.close()

if __name__ == "__main__":
    main()
