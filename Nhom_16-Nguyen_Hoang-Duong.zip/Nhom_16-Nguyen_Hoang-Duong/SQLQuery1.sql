﻿-- Tạo cơ sở dữ liệu QuanLyKhoaHoc
CREATE DATABASE QuanLyKhoaHoc;
GO

-- Chuyển sang cơ sở dữ liệu QuanLyKhoaHoc
USE QuanLyKhoaHoc;
GO
-- Tạo bảng GiangVien
CREATE TABLE GiangVien (
    GiangVienID INT PRIMARY KEY IDENTITY(1,1),
    HoTen NVARCHAR(100),
    NgaySinh DATE,
    ChuyenMon NVARCHAR(100),
    Email NVARCHAR(100),
    SoDienThoai NVARCHAR(15)
);
GO
-- Tạo bảng DeTai
CREATE TABLE DeTai (
    DeTaiID INT PRIMARY KEY IDENTITY(1,1),
    TenDeTai NVARCHAR(200),
    MoTa NVARCHAR(500),
    NgayBatDau DATE,
    NgayKetThuc DATE,
    KinhPhi DECIMAL(18, 2)
);
GO
-- Tạo bảng NghienCuu
CREATE TABLE NghienCuu (
    NghienCuuID INT PRIMARY KEY IDENTITY(1,1),
    GiangVienID INT,
    DeTaiID INT,
    TenNghienCuu NVARCHAR(200),
    NgayThucHien DATE,
    KetQua NVARCHAR(500),
    FOREIGN KEY (GiangVienID) REFERENCES GiangVien(GiangVienID),
    FOREIGN KEY (DeTaiID) REFERENCES DeTai(DeTaiID)
);
GO
-- Tạo bảng GiangVien_DeTai
CREATE TABLE GiangVien_DeTai (
    GiangVienID INT,
    DeTaiID INT,
    VaiTro NVARCHAR(50),
    PRIMARY KEY (GiangVienID, DeTaiID),
    FOREIGN KEY (GiangVienID) REFERENCES GiangVien(GiangVienID),
    FOREIGN KEY (DeTaiID) REFERENCES DeTai(DeTaiID)
);
GO
-- Tạo bảng KetQuaNghienCuu
CREATE TABLE KetQuaNghienCuu (
    KetQuaID INT PRIMARY KEY IDENTITY(1,1),
    NghienCuuID INT,
    LoaiKetQua NVARCHAR(100),
    MoTa NVARCHAR(500),
    NgayDang NVARCHAR(100),
    LinkKetQua NVARCHAR(500),
    FOREIGN KEY (NghienCuuID) REFERENCES NghienCuu(NghienCuuID)
);
GO
-- Tạo bảng TaiTro
CREATE TABLE TaiTro (
    TaiTroID INT PRIMARY KEY IDENTITY(1,1),
    TenTaiTro NVARCHAR(200),
    SoTien DECIMAL(18,2),
    NgayBatDau DATE,
    NgayKetThuc DATE,
    DeTaiID INT,
    FOREIGN KEY (DeTaiID) REFERENCES DeTai(DeTaiID)
);
GO
-- Tạo bảng KhoaHoc
CREATE TABLE KhoaHoc (
    KhoaHocID INT PRIMARY KEY IDENTITY(1,1),
    TenKhoaHoc NVARCHAR(200),
    MoTa NVARCHAR(500),
    SoLuongHocVien INT,
    GiangVienID INT,
    FOREIGN KEY (GiangVienID) REFERENCES GiangVien(GiangVienID)
);
GO
-- Tạo bảng TrangThaiNghienCuu
CREATE TABLE TrangThaiNghienCuu (
    TrangThaiID INT PRIMARY KEY IDENTITY(1,1),
    NghienCuuID INT,
    TrangThai NVARCHAR(50),
    NgayCapNhat DATE,
    FOREIGN KEY (NghienCuuID) REFERENCES NghienCuu(NghienCuuID)
);
GO
-- Thêm giảng viên vào bảng GiangVien
INSERT INTO GiangVien (HoTen, NgaySinh, ChuyenMon, Email, SoDienThoai)
VALUES 
    (N'Nguyễn Văn A', '1985-07-15', N'Vật lý', 'nguyenvana@example.com', '0123456789'),
    (N'Phạm Thị B', '1990-03-10', N'Hóa học', 'phamthib@example.com', '0987654321'),
    (N'Ngô Quang C', '1980-11-22', N'Toán học', 'ngoquangc@example.com', '0912345678');
GO
SELECT * FROM GiangVien;
SELECT * FROM DeTai;
SELECT * FROM NghienCuu;
SELECT * FROM KetQuaNghienCuu;
SELECT * FROM TaiTro;
